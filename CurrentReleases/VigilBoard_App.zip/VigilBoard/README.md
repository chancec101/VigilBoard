***FOR MORE GENERAL INFORMATIION REGARDING VIGILBOARD, PLEASE REFER TO VIGILNET PROJECT PROPOSAL PDF***

---About VigilBoard---

VigilBoard is a program that will scan for vulnerabilties on a system and it will generate a report of ways that the system can be better defended. The goal is to inform those who use the tool how best to defend their systems, despite being outdated.
VigilBoard is more geared towards healthcare database systems that may not be updated to their current version.
VigilBoard was created by following the Unclassified DevSecOpsTools Fundamentals Guidebook PDF file found on this repository in order to ensure proper security at every phase throughout the software development lifecycle.

---VigilBoard Credits---

VigilBoard is a Cybersecurity Capstone collaborative effort between Chance Currie, William Mahoney, Issac Bamidele and David Abbot.
